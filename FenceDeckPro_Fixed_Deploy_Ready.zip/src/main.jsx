import React from 'react'
import ReactDOM from 'react-dom/client'

const App = () => (
  <div className="p-4 space-y-8">
    <header className="text-center space-y-2">
      <h1 className="text-4xl font-bold">FenceDeckPro</h1>
      <p className="text-lg">Fencing, Decking & Retaining Walls – Built Tough for NZ</p>
      <button className="mt-4">Get a Free Quote</button>
    </header>

    <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div>
        <img src="/images/fence1.jpg" alt="Fence" style={{ borderRadius: '8px', width: '100%' }} />
        <h2>Fencing</h2>
        <p>From timber to colorsteel, we install fences that stand the test of time and the Kiwi weather.</p>
      </div>
      <div>
        <img src="/images/deck1.jpg" alt="Deck" style={{ borderRadius: '8px', width: '100%' }} />
        <h2>Decking</h2>
        <p>Upgrade your outdoor space with custom timber and composite decking solutions.</p>
      </div>
      <div>
        <img src="/images/retaining1.jpg" alt="Retaining Wall" style={{ borderRadius: '8px', width: '100%' }} />
        <h2>Retaining Walls</h2>
        <p>Functional and stylish retaining walls that keep your landscape in shape.</p>
      </div>
    </section>
  </div>
)

ReactDOM.createRoot(document.getElementById('root')).render(<App />)
